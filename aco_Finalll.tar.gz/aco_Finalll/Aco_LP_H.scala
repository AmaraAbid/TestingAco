package aco_Finalll
import scala.io.Source

object SAco {
      var Subject : List [String] = List()
      var Object : List [String] = List()
      var Link : List [String] = List() 
      var DisEntities : List [String] = List()
      var AProd : List [Double] = List()
      var AProb : List [Double] = List()
      var Path : List [Int] = List()
      var Weight : List [Int] = List()
      val lambda=0.01
      val epsilon=0.01
      val alpha=0.8
      var beta = 0.7
      val gemma = 0.01
      var prod = 1.0
      var prob = 0.0
      var sum =0.0
      var nextNode:Int = -1
      var WeightIs:Int = -1
      var C = 0.95
      var degree = 0.0
      var Quality = 0.0
      var eRate = 0.7
     def main(args : Array[String]) {
        
        val t1 = System.nanoTime/1e9d
        println("starting time "+ t1/60)
        
        println("Enter number of iterations")
        val iter  = scala.io.StdIn.readInt()
    
        println("Enter number of ants")
        val m  = scala.io.StdIn.readInt()
    
        val Filename= "/home/amara/Data"// data set
       /*for(line <-Source.fromFile(Filename).getLines ){
           println(line)
        } */
        var lines = Source.fromFile(Filename).getLines().toList
        var SLines =       lines.map ( x  =>  {
                      var s = x.split(",")
                      var S = s(0)
                      var O = s(2)
                      var L = s(1)
                      (S,O,L)
         } )
        //(Subject, Object, Link)  = Temp.unzip3
         var t =  SLines.unzip3
         Subject = t._1
         Object = t._2
         Link = t._3
         DisEntities = (Subject ::: Object).distinct
         //println("entities are")
         //DisEntities.foreach(println)
         
         var adjacencyMatrix = Array.ofDim[String] (DisEntities.length+1, DisEntities.length+1) // here DisEntities.length+1 is because of indexing start from zero and last entity was not considered in the case of  DisEntities.length 
        // println("Adjacency Matrix is " )
         for (i <- 0 to lines.length-1 ){
           adjacencyMatrix(Subject(i).toInt)(Object(i).toInt) = Link(i) // sir! 6 datasets are mentioned in paper and 3 of them was available and they were in number format
           adjacencyMatrix(Object(i).toInt)(Subject(i).toInt) = Link(i)
      
         }
        
        /* for (i <- 1 to DisEntities.length){  //if started from 0, 1st row and 1st column prints null and printing of last row and column is skipped 
           for (j <- 1 to DisEntities.length){
             print(" " +adjacencyMatrix(i)(j))
            }
      
          println()
    
         }*/
         var pheromoneMatrix = Array.ofDim[Double] (  DisEntities.length+1, DisEntities.length+1  )
        // println("Pheromone Matrix is " )
         //sir! here condition is on adjacency matrix and updation is on pheromone matrix...unable to understand map function with 2 parameters
         
        for (i <- 1 to DisEntities.length){  //if started from 0, 1st row and 1st column prints null and printing of last row and column is skipped 
           for (j <- 1 to DisEntities.length){ 
              if(adjacencyMatrix(i)(j) != null){
              pheromoneMatrix (i)(j)  =  pheromoneCalculate  (  lambda,  epsilon,  1  ) 
              }
        
              else{
             pheromoneMatrix (i)(j)  =  pheromoneCalculate  (  lambda,  epsilon,  0  )
              }
          //print(" " +pheromoneMatrix(i)(j))
           }
       // println
        }  
         var heuristicMatrix = Array.ofDim[Double](DisEntities.length+1, DisEntities.length+1)
        // println("Heuristic Matrix is " )
         var FNCount = 0
         for (i <- 1 to DisEntities.length)  {
          for (j <- 1 to DisEntities.length){
              var az = adjacencyMatrix(i).zipWithIndex.toList
              var af = az.filter(x => (x._1)!=null)
              var adj = af.map(x=> (x._2))
            
             var a1 = adjacencyMatrix(j).zipWithIndex.toList
             var d1 = a1.filter(x => (x._1)!=null)
             var adj2 = d1.map(x=> (x._2))
                 
           if (i != j) {
              var NCount = adj.map(x => adj2.count(y => (y == x)))
              FNCount = NCount.sum
           }
           else { 
             FNCount = 0
           }
            heuristicMatrix(i)(j) = gemma * FNCount
            //print(" " +heuristicMatrix(i)(j))
         }
        //println()
       }
        var nMax : List[Int] = List() 
        for(i <- 0 to iter-1){
          for (k <- 0 to m-1){  
               var start  =  scala.util.Random.nextInt(DisEntities.length-1)+1
               println("Starting node "+start)
               
                Path = List.fill(DisEntities.length)(0)
                Weight = List.fill(Path.length)(0)
               
               for (i <- 1 to DisEntities.length){
                 var degree = 0.0
                 var Quality = 0.0
                 Path = Path.updated(i-1, start) 
                 println("Path array is")
                 for(a<- Path){
                  println(a)
                 }
                 var adjacentTo  =  adjacencyMatrix(start).filter(_!= null).toList
                 AProd  = List.fill(adjacentTo.length)(0)
                 AProb  = List.fill(adjacentTo.length)(0)
                 
                 /*println("adjacent value"+adjacentTo.length)
                   for(ai <-adjacentTo ){
                      println(ai)     
                    }*/
                 for(i <- 0 to adjacentTo.length-1){
                   var highProb:Double = -1.0
                   var a = adjacencyMatrix(start).zipWithIndex.toList
                   var d = a.filter(x => (x._1)!=null)
                   nMax = d.map(x=> (x._2))
                   var e =  nMax.zipWithIndex
         
                  println("only Nodes of adjacents are ")
                    for(pi<- nMax){
                      println(pi)
                    }
                   
                  /////////////calculating probability//////////////////
                 var pheromone = pheromoneMatrix(start)(nMax(i))
                 var p = Math.pow(pheromone, alpha)
                 //println("pheromone is " +p)
           
                 var heuristic = heuristicMatrix(start)(nMax(i))
                 var  h = Math.pow(heuristic, beta) 
                 //println("heuristic is " +h)
                 
                 var prod = p * h
                 sum = sum + prod
                 AProd = AProd.updated(i, prod)
               }
                 
            for(i<- 0 to AProd.length-1){
               prob = AProd(i)/sum
               AProb = AProb.updated(i, prob)
            }
            /*println("all probs are")
            for(a <- AProb){
              println(a)
            }*/
            
            var maxProb = AProb.max
           // println("Maximun Probability is "+maxProb)
       
            var mIndex = AProb.indexOf(maxProb)
            //println("indexes of max probability is "+ mIndex)
       
            nextNode = nMax(mIndex)
            //println("Next node is "+ nextNode)
      
           // println("weight of max probability is ")
            var WeightIs = adjacentTo(mIndex).toInt
            
            var comp = 0
     
        for(j<-0 to Path.length-1){
        
            for(x<-0 to Path.length-1){
              
                if(nextNode == Path(x)){
                  comp = nextNode
                  
                  var nIndex = nMax.indexOf(comp)
                  var pIndex = AProb.indexOf(comp)
                  var iComp = nMax.patch(nIndex, Nil,  1) 
                  
                  /*println("compared elements" + comp)
                  println("Remaining c's are")
                  for(a <- iComp){
                     println(a)
                  }*/
                  if(nMax.length != 1){
                    var IProb = AProb.patch(AProb.indexOf(maxProb), Nil, 1)
                    var IIProb = IProb.zipWithIndex
                   /* println("Remaining probs are")
                    for(a <- IIProb){
                        println(a)
                       }*/
             
                   var AIndex = adjacentTo.patch(nIndex, Nil, 1)
                  /* println("Remaining adjacents are")
                   for(a <- AIndex){
                      println(a)
                    }*/
                    var maxIProb = IProb.max
                   // println("Maximun of Remaining Probability is "+maxIProb)
            
                    var Iindex = IProb.indexOf(maxIProb)
                    //println("indexes of max probability is "+ Iindex)
            
                    nextNode = iComp(Iindex)
                    //println("Next Remaining node is "+ nextNode)
            
                    WeightIs = AIndex(Iindex).toInt
                   // println("Next Remaining WeightIs is "+ WeightIs)
                    
                    AProb =  IProb.map(x => x)
                    nMax = iComp.map(x => x)
                    adjacentTo = AIndex.map(x => x)
           
                    
                  }
            println( )
                  
            }
         }
      }
            
      Weight = Weight.updated(i-1, WeightIs)
      if(nMax.length != 0){
         start = nextNode
      }
     
      degree = Weight.foldLeft(0)(_ + _)
      //println("degree of path is "+ degree)
    }
  /////////////////////////////////////////Calculating Fitness Sum///////////////////////////////////////////
          
   Quality = C * (1 * degree) / DisEntities.length
   //println("Quality of path is "+ Quality)
          
  
  }
  //////////////////////////////////// pheromone updation ///////////////////////////////////////
  
       for (i <-  1 to Path.length){
         
           for (j <-  1 to Path.length){
          
               for (k <-  j+1 to Path.length-1 ){
        
                   if(k == j+1 ){
                      var p1 = Path(j)
                       var p2 = Path(k)
                       var evp = eRate * pheromoneMatrix(p1)(p2) + Quality
                       pheromoneMatrix = pheromoneMatrix.updated(p1 ,pheromoneMatrix(p1).updated(p2, evp))
                   }
               }
               print(" " +pheromoneMatrix(i)(j))
           }
           println()
       }
       pheromoneMatrix =  pheromoneMatrix.clone()
        }
         
         
        
               
         val t2 = System.nanoTime / 1e9d
         val duration = (t2/60 - t1/60)
         println("Total duration is "+ duration)
  }
      def pheromoneCalculate(lambda:Double,epsilon:Double,link:Int):Double={
    lambda*(link+epsilon)
  }
  
  
}